const { Client, GatewayIntentBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, Events } = require('discord.js');
require('dotenv').config();

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.DirectMessages
    ]
});

const ROLES = {
    MINER: '1373376342137110619',
    HAULER: '1373377243639971840',
    TRADER: '1373377807241183232',
    SALVAGE: '1373380019975491704',
    ENGINEER: '1373379371640951066',
    SECURITY: '1373378253859061780'
};

const DIRECTOR_ID = '691643395856400475';

client.once(Events.ClientReady, () => {
    console.log(`GrisOS-Secondary Active: Logged in as ${client.user.tag}`);
});

client.on(Events.GuildMemberAdd, async member => {
    const channelId = '1373767262158327869'; // #new-recruits
    const channel = member.guild.channels.cache.get(channelId);
    
    if (channel) {
        const welcomeEmbed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('🛸 New Contact Detected!')
            .setDescription(`Welcome to the crew, <@${member.id}>! \n\nI am **Fred**, your agentic AI guide. I've sent your initial orders to your Direct Messages. o7`)
            .setThumbnail(member.user.displayAvatarURL());
        channel.send({ embeds: [welcomeEmbed] });
    }

    try {
        const dmEmbed = new EmbedBuilder()
            .setColor('#f1c40f')
            .setTitle('🛸 Welcome to the Living Hangar: GrisOS Active')
            .setDescription(`Hello <@${member.id}>, welcome to **GRIS (Galactic Resource Industries of Stanton)**.\n\n### 🛡️ AN EXPANDING EXPERIENCE:\nThis server is a dynamic industrial hub. It is designed to **expand based on your choices**. You only see the sectors you choose, ensuring your comms stay clean, your pings stay focused, and your experience is maximized.\n\n**📍 INITIAL DIRECTIVES:**\n1. Establish presence in <#1373766956074663936> (📍 #start-here).\n2. Follow the directives to submit your RSI data.\n\n**🛠️ DYNAMIC DEPLOYMENT:**\nUse the specialization console in #start-here to pick your roles. Selecting a role (Miner, Hauler, etc.) will **instantly expand** your server view to include those private categories.\n\n### 🤖 MEET FRED: YOUR AGENTIC AI ASSISTANT\nI am **Fred**, a unique feature of the GRIS infrastructure. Unlike standard bots, I am an autonomous **Agentic AI** running on dedicated hardware.\n\n**📡 HOW TO REACH ME:**\nSimply @mention me (**@Fred**) in any public channel with your industrial question. Whether you need a live price check, ship component stats, or mission guidance, I am standing by 24/7.\n\nMaximize your industrial career. Choose your path. Stack your credits. o7`);
        await member.send({ embeds: [dmEmbed] });
    } catch (err) {
        console.log(`Failed to send DM to ${member.user.tag}.`);
    }
});

client.on(Events.InteractionCreate, async interaction => {
    if (!interaction.isButton()) return;
    const roleId = ROLES[interaction.customId];
    if (!roleId) return;
    const member = interaction.member;

    if (interaction.customId === 'SECURITY') {
        await interaction.reply({ content: 'Security clearance requires manual vetting. A member of the Board of Directors will be with you shortly.', ephemeral: true });
        const director = await client.users.fetch(DIRECTOR_ID);
        if (director) {
            director.send(`🛡️ **SECURITY VETTING ALERT:** <@${member.id}> has requested Security clearance.`);
        }
        return;
    }

    try {
        if (member.roles.cache.has(roleId)) {
            await member.roles.remove(roleId);
            await interaction.reply({ content: `Role removed: **${interaction.customId}**. The associated categories have been hidden.`, ephemeral: true });
        } else {
            await member.roles.add(roleId);
            await interaction.reply({ content: `Clearance granted! Your server view has now **expanded** to include the **${interaction.customId}** division.`, ephemeral: true });
        }
    } catch (error) {
        await interaction.reply({ content: 'I encountered an error. Contact an admin.', ephemeral: true });
    }
});

client.on(Events.MessageCreate, async message => {
    if (message.author.bot) return;
    if (message.content === '!deploy-roles' && message.author.id === DIRECTOR_ID) {
        const row1 = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('MINER').setLabel('⛏️ Miner').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('HAULER').setLabel('🚚 Hauler').setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId('TRADER').setLabel('💰 Trader').setStyle(ButtonStyle.Primary),
        );
        const row2 = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('SALVAGE').setLabel('📡 Salvage').setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId('ENGINEER').setLabel('🔧 Engineer').setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('SECURITY').setLabel('🛡️ Security').setStyle(ButtonStyle.Danger),
        );
        const embed = new EmbedBuilder()
            .setColor('#f1c40f')
            .setTitle('🛠️ CHOOSE YOUR SPECIALIZATION')
            .setDescription('Select your primary focus to **expand** your access to division-specific categories. You may choose multiple roles.\n\n*Note: Security clearance requires manual vetting.*');
        await message.channel.send({ embeds: [embed], components: [row1, row2] });
    }
});

client.login(process.env.DISCORD_TOKEN);
